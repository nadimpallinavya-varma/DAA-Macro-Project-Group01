# DAA Macro Project

| Unit | Project | Folder |
|------|---------|--------|
| II - Divide and Conquer / Greedy | 4. Greedy Job Sequencing Flowchart | `Unit2_DivideAndConquer_Greedy/` |

Other units follow the same structure: source file, `Prompt.txt`, `Visualization.png`, `README.md`.
